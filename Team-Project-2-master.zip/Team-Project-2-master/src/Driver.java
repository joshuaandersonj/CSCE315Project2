import java.io.IOException;

import javax.swing.JFrame;

public class Driver {

	// Entry point for the game
	public static void main(String[] args){	

		//testMiniMax a = new testMiniMax();
		//a.doStuff();
		Menu game = new Menu();
		//board chess_gui = new board(false, true, false, "white", "easy","localhost");
	}

}
